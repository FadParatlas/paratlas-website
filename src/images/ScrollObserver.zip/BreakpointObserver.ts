
export type Breakpoint = {
    name: string,
    min: number,
    max: number
}

const breakpoints: Breakpoint[] = [
    //{ name: 'sm',  min:    0, max: 1000 },
    { name: 'lg',  min: 0, max: 9999 },
    /*
    { name: 'sm',  min:    0, max:  640 },
    { name: 'md',  min:  641, max:  768 },
    { name: 'lg',  min:  769, max: 1024 },
    { name: 'xl',  min: 1025, max: 1280 },
    { name: '2xl', min: 1281, max: 1536 },
    { name: '3xl', min: 1537, max: 9999 },
    */
];

export type BreakpointObserverSubject = {
    onChange: (breakpoint: Breakpoint) => void;
}

export class BreakpointObserver {

    private readonly _breakpoints: Breakpoint[];
    private _current: Breakpoint;
    private _previous: Breakpoint | null = null;
    private _observers: BreakpointObserverSubject[] = [];
    //private _lastBreakpoint: string = '';

    constructor(breakpoints: Breakpoint[]) {
        if (breakpoints.length > 0) {
            this._breakpoints = breakpoints;

            this._current = this._breakpoints[0];
            this._update();

            window.addEventListener('resize', () => {
                this._update();
                console.log(`breakpoint "${this._current.name}"`);
            });
        }
        else {
            console.warn('No breakpoints specified!');
        }
    }

    public add(observer: BreakpointObserverSubject): void {
        this._observers.push(observer);
        if (breakpoints.length > 0) {
            this._update();
        }
        else {
            console.warn('No breakpoints specified!');
        }
    }

    private _update(): void {
        const width = document.body.clientWidth;
        const breakpoint = this._breakpoints.find(breakpoint => (width >= breakpoint.min && width <= breakpoint.max));
        this._current = breakpoint ? breakpoint : this._breakpoints[0];

        // If breakpoint has changed, execute observer callbacks.
        if (!this._previous || this._current.name !== this._previous.name) {
            for (let observer of this._observers) {
                observer.onChange(this._current);
            }
            this._previous = this._current;
        }
    }

    public get current(): Breakpoint {
        return this._current;
    }
}
export const breakpointObserver = new BreakpointObserver(breakpoints);
