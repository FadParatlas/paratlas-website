import { Vector2, Vector3 } from '@babylonjs/core/Maths/math.vector';

export default class Utils {

    public static Kebab2Camelcase(s: string): string {
        return s.replace(/-./g, x => x[1].toUpperCase());
    }

    public static RandomColor(opacity: number = 1.0): string {
        const r = Math.round((Math.random() * 255));
        const g = Math.round((Math.random() * 255));
        const b = Math.round((Math.random() * 255));
        return `rgba(${r}, ${g}, ${b}, ${opacity})`;
    }

    public static GetNumberDataAttribute(element: HTMLElement, attributeName: string, defaultValue: number): number {
        const attributeValue = element.getAttribute(`data-${attributeName}`);
        return attributeValue ? parseFloat(attributeValue) : defaultValue;
    }

    public static GetStringDataAttribute(element: HTMLElement, attributeName: string, defaultValue: string): string {
        const attributeValue = element.getAttribute(`data-${attributeName}`);
        return attributeValue ? attributeValue : defaultValue;
    }

    public static GetBooleanDataAttribute(element: HTMLElement, attributeName: string, defaultValue: boolean): boolean {
        const attributeExists = element.hasAttribute(`data-${attributeName}`);
        const attributeValue = element.getAttribute(`data-${attributeName}`);
        return attributeExists ? (attributeValue ? (attributeValue === 'true') : true) : defaultValue;
    }

    public static GetVector3DataAttribute(element: HTMLElement, attributeName: string, defaultValue: Vector3): Vector3 {
        const attributeValue = element.getAttribute(`data-${attributeName}`);
        let vec = defaultValue;
        if (attributeValue) {
            const strArr = attributeValue.split('|');
            const numArr: number[] = [];
            if (strArr.length >= 2) {
                for (let i = 0; i < 3; i++) {
                    let num = parseFloat(strArr[i]);
                    num = isNaN(num) ? 0 : num;
                    numArr.push(num);
                }
                vec = Vector3.FromArray(numArr);
            }
        }
        return vec;
    }

    public static GetVector2DataAttribute(element: HTMLElement, attributeName: string, defaultValue: Vector2): Vector2 {
        const attributeValue = element.getAttribute(`data-${attributeName}`);
        let vec = defaultValue;
        if (attributeValue) {
            const strArr = attributeValue.split('|');
            const numArr: number[] = [];
            if (strArr.length >= 1) {
                for (let i = 0; i < 2; i++) {
                    let num = parseFloat(strArr[i]);
                    num = isNaN(num) ? 0 : num;
                    numArr.push(num);
                }
                vec = Vector2.FromArray(numArr);
            }
        }
        return vec;
    }

    private static _eachElement(selectors: string, callback: (elem: HTMLElement) => void) {
        document.querySelectorAll(selectors).forEach((elem) => {
            callback(elem as HTMLElement);
        });
    }

    public static AddClass(selectors: string, className: string) : void {
        Utils._eachElement(selectors, (element) => {
            if (!element.classList.contains(className)) {
                element.classList.add(className);
            }
        });
    }

    public static RemoveClass(selectors: string, className: string) : void {
        Utils._eachElement(selectors, (element) => {
            element.classList.remove(className);
        });
    }

    
    public static ShowElements(selectors: string, show: boolean) : void {
        Utils._eachElement(selectors, (element) => {
            show ? element.classList.remove('hide') : element.classList.add('hide');
        });
    }
}
