import { breakpointObserver } from './BreakpointObserver';
import Utils from './Utils';

export class ScrollObserver {

    private _lastPos: number = 0;
    private _zones: ScrollZone[] = [];
    private _lastBreakpoint: string = breakpointObserver.current.name;

    constructor() {
        window.requestAnimationFrame(() => {
            this._update();
        });

        window.addEventListener('resize', () => {
            const breakpoint = breakpointObserver.current.name;
            if (breakpoint !== this._lastBreakpoint) {
                console.log(`Breakpoint changed to ${breakpoint}`);
                for (let zone of this._zones) {
                    zone.breakpoint = breakpoint;
                }
                this._lastBreakpoint = breakpoint;
            }
        });
    }

    public addZone(name: string, target: any, options: ScrollZoneOptions) {
        const zone = new ScrollZone(name, target, options, breakpointObserver.current.name);
        this._zones.push(zone);
        return zone;
    }

    private _checkZones() {
        for (let zone of this._zones) {

            if (zone.dirty) {
                continue;
            }

            if (!zone.inRange()) {
                const scrollTop = ScrollObserver.ScrollTop();
                if (scrollTop < zone.start) {
                    if (zone.value !== 0) {
                        zone.value = 0;
                        zone.dirty = true;
                    }
                }
                else {
                    if (zone.value !== 1) {
                        zone.value = 1;
                        zone.dirty = true;
                    }
                }
            }
            else {
                zone.dirty = true;
            }

            if (zone.dirty) {
                zone.update();
            }
        }
    }

    private _update(): void {
        const scrollTop = ScrollObserver.ScrollTop();
        if (this._lastPos !== scrollTop) {
            this._lastPos = scrollTop;
            this._checkZones();
        }

        window.requestAnimationFrame(() => {
            this._update();
        });
    }

    public static ScrollTop() {
        return Math.max(window.pageYOffset, document.documentElement.scrollTop, document.body.scrollTop);
    }
}

export type ScrollZoneRange = {
    breakpoint: string,
    start: number,
    end: number
}

export type ScrollZoneOptions = {
    ranges: ScrollZoneRange[],
    debug?: boolean,
    startDirty?: boolean,
    onEnter?: (target: HTMLElement | null) => void,
    onUpdate: (value: number, target: HTMLElement | null) => void,
    onLeave?: (target: HTMLElement | null) => void,
}

export class ScrollZone {

    private _name: string;
    private _target: HTMLElement | null;
    private _ranges: ScrollZoneRange[];
    private _start: number = 0;
    private _end: number = 0;
    private _debug: boolean;
    private _debugDiv: HTMLDivElement | null = null;
    private _onEnter: null | ((target: HTMLElement | null) => void);
    private _onUpdate: (value: number, target: HTMLElement | null) => void;
    private _onLeave: null | ((target: HTMLElement | null) => void);
    private _value: number = 0;
    private _dirty: boolean = false;
    private _wasInRange: boolean = false;
    private _breakpoint: string = '';

    constructor(name: string, target: HTMLElement | null, options: ScrollZoneOptions, breakpoint: string) {
        this._name = name;
        this._target = target;

        // Order of execution CRITICAL below!

        // Setup visual debugging for this zone.
        this._debug = options.debug ?? false;
        if (this._debug) {
            this._debugDiv = document.createElement('div');
            this._debugDiv.style.display = 'block';
            this._debugDiv.style.position = 'absolute';
            this._debugDiv.style.right = '0';
            this._debugDiv.style.width = '100px';
            this._debugDiv.style.zIndex = '10000000';
            this._debugDiv.style.pointerEvents = 'none';
            this._debugDiv.style.background = Utils.RandomColor(0.2);
            this._debugDiv.innerHTML = `${this._name}`;
            document.body.appendChild(this._debugDiv);
        }

        this._onEnter = options.onEnter ?? null;
        this._onUpdate = options.onUpdate;
        this._onLeave = options.onLeave ?? null;
        this._ranges = options.ranges;
        this.breakpoint = breakpoint;

        const startDirty = options.startDirty ?? true;
        if (!startDirty) {
            this.dirty = false;
        }
        else {
            this.dirty = true;
            this.update();
        }
    }

    public inRange(): boolean {
        const scrollTop = ScrollObserver.ScrollTop();
        const inRange = this.start < scrollTop === scrollTop < this.end;
        if (this._onEnter && inRange && !this._wasInRange) {
            this._onEnter(this._target);
        }
        if (this._onLeave && !inRange && this._wasInRange) {
            this._onLeave(this._target);
        }
        this._wasInRange = inRange;
        return inRange;
    }

    public update(): void {
        this.value = Math.max(Math.min(((ScrollObserver.ScrollTop() - this.start)) / (this.end - this.start), 1), 0);
        this._onUpdate(this.value, this._target);
        this.dirty = false;
    }

    get start(): number {
        return this._start;
    }
    get end(): number {
        return this._end;
    }

    get value(): number {
        return this._value;
    }

    set value(value: number) {
        this._value = value;
    }

    get dirty(): boolean {
        return this._dirty;
    }

    set dirty(value: boolean) {
        this._dirty = value;
    }

    set breakpoint(value: string) {
        this._breakpoint = value;

        // Update zone start and end based on current breakpoint.
        const range = this._ranges.find(range => (this._breakpoint === range.breakpoint));
        this._start = range!.start;
        this._end = range!.end;

        // Show zone height and position in the visual debugger.
        if (this._debugDiv) {
            this._debugDiv.style.top = `${this.start}px`;
            this._debugDiv.style.height = `${this.end - this.start}px`;
        }

        // Update zone.
        this.dirty = true;
        this.update();
    }
}

export const scrollObserver = new ScrollObserver();
